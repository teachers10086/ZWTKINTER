
# ZWTKINTER

A simplified Chinese Tkinter GUI component library.

## Installation

You can install the package using `pip`:

```bash
pip install ZWTKINTER
